-- ========================================
-- SCRIPT COMPLETO DE POPULAÇÃO DO BANCO
-- Sistema de Gestão de Estoque - Agroindústria
-- ========================================

-- Usar o banco de dados
USE agroindustria_db;

-- ========================================
-- LIMPAR DADOS EXISTENTES (OPCIONAL)
-- ========================================
-- Descomente as linhas abaixo se quiser limpar dados antigos
-- DELETE FROM stock_alerts;
-- DELETE FROM stock_movements;
-- DELETE FROM stock_entries;
-- DELETE FROM raw_materials;
-- DELETE FROM suppliers;
-- DELETE FROM users;

-- ========================================
-- INSERIR USUÁRIOS
-- ========================================
INSERT IGNORE INTO users (id, username, email, password, role, is_active, created_at) VALUES
(1, 'admin', 'admin@agroindustria.com', 'e3b0c44298fc1c149afbf4c8996fb92427ae41e4649b934ca495991b7852b855', 'admin', 1, NOW()),
(2, 'gerente', 'gerente@agroindustria.com', 'e3b0c44298fc1c149afbf4c8996fb92427ae41e4649b934ca495991b7852b855', 'admin', 1, NOW()),
(3, 'operador1', 'operador1@agroindustria.com', 'e3b0c44298fc1c149afbf4c8996fb92427ae41e4649b934ca495991b7852b855', 'operador', 1, NOW()),
(4, 'operador2', 'operador2@agroindustria.com', 'e3b0c44298fc1c149afbf4c8996fb92427ae41e4649b934ca495991b7852b855', 'operador', 1, NOW()),
(5, 'analista', 'analista@agroindustria.com', 'e3b0c44298fc1c149afbf4c8996fb92427ae41e4649b934ca495991b7852b855', 'operador', 1, NOW());

-- ========================================
-- INSERIR FORNECEDORES
-- ========================================
INSERT IGNORE INTO suppliers (id, name, email, phone, cnpj, address, city, state, is_active, created_by, created_at) VALUES
(1, 'Agrícola Brasil Ltda', 'contato@agricolabrasil.com.br', '(11) 3456-7890', '12.345.678/0001-90', 'Av. Paulista, 1000', 'São Paulo', 'SP', 1, 1, NOW()),
(2, 'Grãos do Centro', 'vendas@graoscentro.com.br', '(34) 9876-5432', '23.456.789/0001-01', 'Rua das Flores, 500', 'Uberlândia', 'MG', 1, 1, NOW()),
(3, 'Sementes Premium', 'comercial@sementespremium.com.br', '(47) 3333-4444', '34.567.890/0001-12', 'Estrada Rural, 200', 'Blumenau', 'SC', 1, 1, NOW()),
(4, 'Fertilizantes Globais', 'vendas@fertglobais.com.br', '(85) 9999-8888', '45.678.901/0001-23', 'Av. Industrial, 1500', 'Fortaleza', 'CE', 1, 1, NOW()),
(5, 'Insumos Agrícolas Sul', 'contato@insumoagricola.com.br', '(51) 2222-3333', '56.789.012/0001-34', 'Rua do Comércio, 300', 'Porto Alegre', 'RS', 1, 1, NOW()),
(6, 'Produtos Agrícolas Norte', 'vendas@agrinorte.com.br', '(92) 3333-4444', '67.890.123/0001-45', 'Estrada da Amazônia, 800', 'Manaus', 'AM', 1, 1, NOW()),
(7, 'Agrotech Inovação', 'comercial@agrotechinov.com.br', '(31) 8888-9999', '78.901.234/0001-56', 'Av. Tecnológica, 2000', 'Belo Horizonte', 'MG', 1, 1, NOW());

-- ========================================
-- INSERIR MATÉRIAS-PRIMAS
-- ========================================
INSERT IGNORE INTO raw_materials (id, name, category, unit, current_stock, minimum_stock, maximum_stock, unit_cost, is_active, created_by, created_at) VALUES
-- Grãos
(1, 'Milho Amarelo', 'Grãos', 'kg', 5000.00, 1000.00, 10000.00, 0.85, 1, 1, NOW()),
(2, 'Soja', 'Grãos', 'kg', 3500.00, 800.00, 8000.00, 1.20, 1, 1, NOW()),
(3, 'Trigo', 'Grãos', 'kg', 2800.00, 500.00, 6000.00, 0.95, 1, 1, NOW()),
(4, 'Arroz', 'Grãos', 'kg', 4200.00, 1000.00, 9000.00, 1.10, 1, 1, NOW()),
(5, 'Milho Branco', 'Grãos', 'kg', 2200.00, 400.00, 5000.00, 0.90, 1, 1, NOW()),
(6, 'Sorgo', 'Grãos', 'kg', 1800.00, 300.00, 4000.00, 0.75, 1, 1, NOW()),
-- Fertilizantes
(7, 'Nitrogênio (N)', 'Fertilizantes', 'kg', 1500.00, 300.00, 3000.00, 2.50, 1, 1, NOW()),
(8, 'Fósforo (P)', 'Fertilizantes', 'kg', 1200.00, 250.00, 2500.00, 3.00, 1, 1, NOW()),
(9, 'Potássio (K)', 'Fertilizantes', 'kg', 1800.00, 400.00, 3500.00, 2.75, 1, 1, NOW()),
(10, 'Ureia', 'Fertilizantes', 'kg', 2500.00, 500.00, 5000.00, 1.80, 1, 1, NOW()),
(11, 'Superfosfato Simples', 'Fertilizantes', 'kg', 1600.00, 300.00, 3500.00, 2.20, 1, 1, NOW()),
-- Sementes
(12, 'Sementes de Milho Híbrido', 'Sementes', 'kg', 800.00, 150.00, 2000.00, 8.50, 1, 1, NOW()),
(13, 'Sementes de Soja', 'Sementes', 'kg', 600.00, 100.00, 1500.00, 9.20, 1, 1, NOW()),
(14, 'Sementes de Trigo', 'Sementes', 'kg', 450.00, 80.00, 1200.00, 7.80, 1, 1, NOW()),
(15, 'Sementes de Arroz', 'Sementes', 'kg', 350.00, 60.00, 1000.00, 8.00, 1, 1, NOW()),
-- Aditivos e Corretivos
(16, 'Calcário Agrícola', 'Aditivos', 'kg', 2500.00, 500.00, 5000.00, 0.45, 1, 1, NOW()),
(17, 'Enxofre', 'Aditivos', 'kg', 1000.00, 200.00, 2500.00, 1.80, 1, 1, NOW()),
(18, 'Micronutrientes', 'Aditivos', 'kg', 300.00, 50.00, 800.00, 15.00, 1, 1, NOW()),
(19, 'Gesso Agrícola', 'Aditivos', 'kg', 1200.00, 250.00, 3000.00, 0.55, 1, 1, NOW()),
(20, 'Ácido Bórico', 'Aditivos', 'kg', 250.00, 40.00, 600.00, 12.50, 1, 1, NOW());

-- ========================================
-- INSERIR ENTRADAS DE ESTOQUE
-- ========================================
INSERT IGNORE INTO stock_entries (id, raw_material_id, supplier_id, quantity, unit, lot_number, entry_date, expiry_date, unit_cost, total_cost, notes, created_by, created_at) VALUES
-- Grãos - Entradas
(1, 1, 1, 2000.00, 'kg', 'LOTE-MILHO-001-2024', '2024-01-15', '2025-01-15', 0.85, 1700.00, 'Milho de qualidade premium, sem impurezas', 1, NOW()),
(2, 2, 2, 1500.00, 'kg', 'LOTE-SOJA-001-2024', '2024-01-18', '2025-01-18', 1.20, 1800.00, 'Soja certificada, teor de proteína 38%', 1, NOW()),
(3, 3, 1, 1200.00, 'kg', 'LOTE-TRIGO-001-2024', '2024-01-20', '2025-01-20', 0.95, 1140.00, 'Trigo tipo 1, força 280', 1, NOW()),
(4, 4, 3, 1800.00, 'kg', 'LOTE-ARROZ-001-2024', '2024-01-22', '2025-01-22', 1.10, 1980.00, 'Arroz integral, grão longo', 1, NOW()),
(5, 5, 1, 1000.00, 'kg', 'LOTE-MILHO-BRANCO-001-2024', '2024-01-25', '2025-01-25', 0.90, 900.00, 'Milho branco para processamento', 1, NOW()),
(6, 6, 2, 800.00, 'kg', 'LOTE-SORGO-001-2024', '2024-01-28', '2025-01-28', 0.75, 600.00, 'Sorgo para ração animal', 1, NOW()),
-- Fertilizantes - Entradas
(7, 7, 4, 500.00, 'kg', 'LOTE-NITRO-001-2024', '2024-01-25', '2025-01-25', 2.50, 1250.00, 'Nitrogênio puro, 46% N', 1, NOW()),
(8, 8, 4, 400.00, 'kg', 'LOTE-FOSF-001-2024', '2024-01-25', '2025-01-25', 3.00, 1200.00, 'Fósforo puro, 46% P2O5', 1, NOW()),
(9, 9, 4, 600.00, 'kg', 'LOTE-POTASS-001-2024', '2024-01-25', '2025-01-25', 2.75, 1650.00, 'Potássio puro, 60% K2O', 1, NOW()),
(10, 10, 4, 800.00, 'kg', 'LOTE-UREIA-001-2024', '2024-02-01', '2025-02-01', 1.80, 1440.00, 'Ureia 46% N, grânulos', 1, NOW()),
(11, 11, 5, 500.00, 'kg', 'LOTE-SUPERF-001-2024', '2024-02-05', '2025-02-05', 2.20, 1100.00, 'Superfosfato simples 18% P2O5', 1, NOW()),
-- Sementes - Entradas
(12, 12, 3, 300.00, 'kg', 'LOTE-SEMILHO-001-2024', '2024-02-01', '2025-02-01', 8.50, 2550.00, 'Sementes híbridas certificadas, germinação 95%', 1, NOW()),
(13, 13, 3, 250.00, 'kg', 'LOTE-SEMSOJA-001-2024', '2024-02-01', '2025-02-01', 9.20, 2300.00, 'Sementes de soja certificadas, germinação 92%', 1, NOW()),
(14, 14, 3, 200.00, 'kg', 'LOTE-SEMTRIGO-001-2024', '2024-02-01', '2025-02-01', 7.80, 1560.00, 'Sementes de trigo certificadas, germinação 90%', 1, NOW()),
(15, 15, 3, 150.00, 'kg', 'LOTE-SEMARROZ-001-2024', '2024-02-05', '2025-02-05', 8.00, 1200.00, 'Sementes de arroz certificadas, germinação 88%', 1, NOW()),
-- Aditivos - Entradas
(16, 16, 5, 1000.00, 'kg', 'LOTE-CALC-001-2024', '2024-02-05', '2025-02-05', 0.45, 450.00, 'Calcário dolomítico, PRNT 90%', 1, NOW()),
(17, 17, 5, 400.00, 'kg', 'LOTE-ENXO-001-2024', '2024-02-05', '2025-02-05', 1.80, 720.00, 'Enxofre em pó, pureza 99%', 1, NOW()),
(18, 18, 4, 150.00, 'kg', 'LOTE-MICRO-001-2024', '2024-02-10', '2025-02-10', 15.00, 2250.00, 'Micronutrientes complexos (B, Cu, Mn, Zn)', 1, NOW()),
(19, 19, 6, 600.00, 'kg', 'LOTE-GESSO-001-2024', '2024-02-12', '2025-02-12', 0.55, 330.00, 'Gesso agrícola, 23% Ca', 1, NOW()),
(20, 20, 7, 100.00, 'kg', 'LOTE-ACIDO-001-2024', '2024-02-15', '2025-02-15', 12.50, 1250.00, 'Ácido Bórico, pureza 99.5%', 1, NOW());

-- ========================================
-- INSERIR MOVIMENTAÇÕES DE ESTOQUE
-- ========================================
INSERT IGNORE INTO stock_movements (id, raw_material_id, type, quantity, unit, reason, created_by, created_at) VALUES
-- Entradas
(1, 1, 'entrada', 2000.00, 'kg', 'Entrada de estoque - Lote LOTE-MILHO-001-2024', 1, NOW()),
(2, 2, 'entrada', 1500.00, 'kg', 'Entrada de estoque - Lote LOTE-SOJA-001-2024', 1, NOW()),
(3, 3, 'entrada', 1200.00, 'kg', 'Entrada de estoque - Lote LOTE-TRIGO-001-2024', 1, NOW()),
(4, 4, 'entrada', 1800.00, 'kg', 'Entrada de estoque - Lote LOTE-ARROZ-001-2024', 1, NOW()),
(5, 5, 'entrada', 1000.00, 'kg', 'Entrada de estoque - Lote LOTE-MILHO-BRANCO-001-2024', 1, NOW()),
(6, 6, 'entrada', 800.00, 'kg', 'Entrada de estoque - Lote LOTE-SORGO-001-2024', 1, NOW()),
(7, 7, 'entrada', 500.00, 'kg', 'Entrada de estoque - Lote LOTE-NITRO-001-2024', 1, NOW()),
(8, 8, 'entrada', 400.00, 'kg', 'Entrada de estoque - Lote LOTE-FOSF-001-2024', 1, NOW()),
(9, 9, 'entrada', 600.00, 'kg', 'Entrada de estoque - Lote LOTE-POTASS-001-2024', 1, NOW()),
(10, 10, 'entrada', 800.00, 'kg', 'Entrada de estoque - Lote LOTE-UREIA-001-2024', 1, NOW()),
-- Saídas por Processamento
(11, 1, 'saida', 150.00, 'kg', 'Uso em processamento de ração animal', 2, NOW()),
(12, 2, 'saida', 100.00, 'kg', 'Uso em processamento de óleo vegetal', 2, NOW()),
(13, 3, 'saida', 80.00, 'kg', 'Uso em processamento de farinha', 2, NOW()),
(14, 4, 'saida', 120.00, 'kg', 'Uso em processamento de arroz beneficiado', 3, NOW()),
(15, 5, 'saida', 90.00, 'kg', 'Uso em processamento de fubá', 3, NOW()),
-- Entradas Adicionais
(16, 12, 'entrada', 300.00, 'kg', 'Entrada de estoque - Lote LOTE-SEMILHO-001-2024', 1, NOW()),
(17, 13, 'entrada', 250.00, 'kg', 'Entrada de estoque - Lote LOTE-SEMSOJA-001-2024', 1, NOW()),
(18, 14, 'entrada', 200.00, 'kg', 'Entrada de estoque - Lote LOTE-SEMTRIGO-001-2024', 1, NOW()),
(19, 16, 'entrada', 1000.00, 'kg', 'Entrada de estoque - Lote LOTE-CALC-001-2024', 1, NOW()),
(20, 17, 'entrada', 400.00, 'kg', 'Entrada de estoque - Lote LOTE-ENXO-001-2024', 1, NOW()),
-- Saídas Adicionais
(21, 7, 'saida', 50.00, 'kg', 'Venda para cliente externo', 2, NOW()),
(22, 8, 'saida', 40.00, 'kg', 'Venda para cliente externo', 2, NOW()),
(23, 9, 'saida', 60.00, 'kg', 'Venda para cliente externo', 3, NOW()),
(24, 12, 'saida', 30.00, 'kg', 'Uso em plantio experimental', 4, NOW()),
(25, 16, 'saida', 200.00, 'kg', 'Uso em correção de solo', 3, NOW());

-- ========================================
-- INSERIR ALERTAS DE ESTOQUE
-- ========================================
INSERT IGNORE INTO stock_alerts (id, raw_material_id, alert_type, message, is_resolved, created_at) VALUES
(1, 14, 'low_stock', 'Estoque de Sementes de Trigo abaixo do mínimo (450 kg < 80 kg recomendado)', 0, NOW()),
(2, 18, 'low_stock', 'Estoque de Micronutrientes abaixo do mínimo (300 kg < 50 kg recomendado)', 0, NOW()),
(3, 15, 'low_stock', 'Estoque de Sementes de Arroz abaixo do mínimo (350 kg < 60 kg recomendado)', 0, NOW()),
(4, 20, 'critical_stock', 'Estoque de Ácido Bórico CRÍTICO (250 kg < 40 kg recomendado)', 0, NOW()),
(5, 6, 'low_stock', 'Estoque de Sorgo abaixo do mínimo (1800 kg < 300 kg recomendado)', 1, NOW());

-- ========================================
-- VERIFICAR DADOS INSERIDOS
-- ========================================
SELECT 'Usuários' as Tabela, COUNT(*) as Total FROM users
UNION ALL
SELECT 'Fornecedores', COUNT(*) FROM suppliers
UNION ALL
SELECT 'Matérias-Primas', COUNT(*) FROM raw_materials
UNION ALL
SELECT 'Entradas de Estoque', COUNT(*) FROM stock_entries
UNION ALL
SELECT 'Movimentações', COUNT(*) FROM stock_movements
UNION ALL
SELECT 'Alertas', COUNT(*) FROM stock_alerts;

-- ========================================
-- FIM DO SCRIPT
-- ========================================
